# orchestrator.py

import os
import json
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
import traceback

from modules.tool_definitions import get_merchant_profile, get_festival_info
from modules.knowledge_base import (
    search_contextual_marketing_strategy,
    load_festival_vector_store 
)
from modules.filtering import run_festival_recommendation
from modules.generation import format_final_response

class AgentOrchestrator:
    def __init__(self, google_api_key):
        if not google_api_key:
            raise ValueError("GOOGLE_API_KEY가 설정되지 않았습니다.")
        
        # 도구 사용 및 평가용 LLM
        self.llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", google_api_key=google_api_key, temperature=0.1)

        self.tools = [get_merchant_profile, get_festival_info, search_contextual_marketing_strategy]
        self.llm_with_tools = self.llm.bind_tools(self.tools) 


    # streamlit_app.py의 1단계(프로필 확인)에서 호출하는 함수
    def get_store_profile_only(self, merchant_id: str) -> dict:
        """
        Streamlit 앱의 1단계(프로필 확인)를 위해 
        'get_merchant_profile' 도구를 직접 호출하여 프로필 데이터만 반환합니다.
        """
        print(f"--- [Orchestrator] get_store_profile_only 호출 (ID: {merchant_id}) ---")
        try:
            # tool_definitions.py에 정의된 get_merchant_profile 함수를 직접 호출
            profile_data = get_merchant_profile.invoke({"merchant_id": merchant_id})
            
            if not profile_data or "error" in profile_data:
                print(f"--- [Orchestrator ERROR] 프로필 조회 실패: {profile_data}")
                return {"error": profile_data.get("error", "프로필을 조회하지 못했습니다.")}
            
            print(f"--- [Orchestrator] 프로필 조회 성공 ---")
            return profile_data

        except Exception as e:
            print(f"--- [Orchestrator CRITICAL] get_store_profile_only 실패: {e}\n{traceback.format_exc()}")
            return {"error": f"프로필 조회 중 심각한 오류 발생: {e}"}


    def execute_plan(self, user_query: str, merchant_name: str, merchant_id: str, profile_data: dict) -> dict:
        """
        (수정됨) 4단계 파이프라인을 실행합니다.
        1. (Input) 가게 프로필 확인
        2. (Filter) 고도화된 축제 추천 파이프라인 실행 (filtering.py 호출)
        3. (Tool) RAG로 마케팅 전략 검색
        4. (Generate) 최종 보고서 생성
        """
        print(f"--- [Orchestrator] execute_plan 시작 (Query: {user_query}) ---")
        try:
            # 1. (Input) 가게 프로필 확인
            store_profile = profile_data.get('store_profile', {})
            if not store_profile:
                return {"error": "가게 프로필 데이터를 찾을 수 없습니다."}
            
            print("--- [Orchestrator] 1. 가게 프로필 확인 완료 ---")

            # --- [수정된 로직 시작] ---
            # filtering.py의 새 파이프라인을 사용하도록 기존 3, 4, 5단계 로직을 대체
            
            # 2. (Filter) 고도화된 축제 추천 파이프라인 실행
            print("--- [Orchestrator] 2. (Filter) 고도화된 축제 추천 파이프라인 실행 ---")
            
            # knowledge_base에서 캐시된 벡터 스토어를 로드
            festival_vector_store, _ = load_festival_vector_store()
            if festival_vector_store is None:
                return {"error": "축제 벡터 스토어를 로드하지 못했습니다."}

            # filtering.py의 메인 함수 호출
            recommendation_result = run_festival_recommendation(
                store_profile=store_profile,
                user_query=user_query,
                top_k=15,  # 추천 후보 수 (필요시 조절)
                vector_store=festival_vector_store,
                llm=self.llm # Orchestrator의 LLM 객체 전달
            )
            
            # 오류 처리
            if "error" in recommendation_result:
                print(f"--- [Orchestrator ERROR] run_festival_recommendation 실패: {recommendation_result['error']} ---")
                return {"error": recommendation_result['error']}

            # 결과 추출
            final_recommendations = recommendation_result.get("recommendations", [])
            scoring_criteria = recommendation_result.get("scoring_criteria", {})
            
            if not final_recommendations:
                 return {"error": "축제 후보를 찾았으나, 최종 추천 생성에 실패했습니다."}
            
            print(f"--- [Orchestrator] 2. 축제 추천 완료 (후보: {len(final_recommendations)}개) ---")
            # --- [수정된 로직 종료] ---

            # 3. (Tool) RAG로 마케팅 전략 검색 (기존 6단계 -> 3단계)
            print("--- [Orchestrator] 3. (Tool) RAG로 마케팅 전략 검색 ---")
            marketing_strategy = search_contextual_marketing_strategy.invoke({
                "store_profile": store_profile,
                "user_query": user_query
            })
            
            # 4. (Generate) 최종 보고서 생성 (기존 7단계 -> 4단계)
            print("--- [Orchestrator] 4. (Generate) 최종 보고서 생성 ---")
            final_response = format_final_response(
                merchant_name=merchant_name,
                user_query=user_query,
                profile_data=profile_data,
                recommendations=final_recommendations,
                scoring_criteria=scoring_criteria,
                marketing_strategy=marketing_strategy
            )
            
            # --- [파이프라인 종료] ---
            print("--- [Orchestrator] execute_plan 성공 ---")
            
            return {
                "final_response": final_response,
                "recommendations": final_recommendations,
                "profile_data": profile_data,
                "scoring_criteria": scoring_criteria,
                "marketing_strategy": marketing_strategy
            }

        except Exception as e:
            print(f"--- [Orchestrator CRITICAL] execute_plan 실패: {e}\n{traceback.format_exc()}")
            return {
                "error": f"알 수 없는 오류가 발생했습니다: {e}",
                "final_response": f"죄송합니다. 요청을 처리하는 중 심각한 오류가 발생했습니다. (오류: {e})",
                "recommendations": [],
                "profile_data": profile_data,
                "scoring_criteria": {},
                "marketing_strategy": "오류로 인해 마케팅 전략을 생성할 수 없습니다."
            }