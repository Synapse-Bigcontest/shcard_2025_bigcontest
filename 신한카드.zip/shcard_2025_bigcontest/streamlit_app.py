# streamlit_app.py

import streamlit as st
import os
import pandas as pd
import re 
import traceback

from orchestrator import AgentOrchestrator
from modules.visualization import display_merchant_profile
from api.data_loader import load_and_preprocess_data
from modules.knowledge_base import load_retriever, load_festival_vector_store

@st.cache_data
def load_data():
    """
    가맹점 목록 데이터를 로드합니다.
    """
    df = load_and_preprocess_data()
    if df is not None:
        return df[['가맹점ID', '가맹점명']].drop_duplicates().reset_index(drop=True)
    return None

st.set_page_config(page_title="신한카드 AI 축제 컨설턴트", page_icon="🎈", layout="wide")

merchant_df = load_data()
if merchant_df is None:
    st.error("데이터 로딩에 실패했습니다. 'data/final_df.csv' 파일이 올바른 위치에 있는지 확인해주세요.")
    st.stop()


def initialize_session():
    """
    (수정됨) 세션 초기화 시, Orchestrator와 모든 AI 모듈(RAG, Vector Store)을
    미리 로드하여 캐시합니다.
    """
    if "orchestrator" not in st.session_state:
        # 1. API 키 로드
        google_api_key = os.environ.get("GOOGLE_API_KEY")
        if not google_api_key:
            st.error("GOOGLE_API_KEY 환경변수가 설정되지 않았습니다.")
            st.stop()
            
        # --- [수정] 앱 시작 시 모든 모델과 벡터스토어 미리 로드 ---
        with st.spinner("AI 모델 및 빅데이터 벡터 DB를 로딩 중입니다..."):
            try:
                # 1. 마케팅 RAG 로더 (기존)
                load_retriever()
                
                # 2. (신규) 축제 추천 벡터 스토어 로더
                #    이 함수가 None을 반환하면 knowledge_base.py에서 st.error를 이미 호출함
                retriever, embeddings = load_festival_vector_store()
                if retriever is None or embeddings is None:
                    # knowledge_base.py에서 이미 st.error를 호출했을 것이므로 여기서는 중단만 함
                    st.error("축제 벡터 스토어 로딩에 실패했습니다. 'build_vector_store.py'를 실행했는지 확인하세요.")
                    st.stop()
                    
                print("--- [Streamlit] 모든 AI 모듈 로딩 완료 ---")

            except Exception as e:
                st.error(f"AI 모듈 초기화 중 오류 발생: {e}")
                traceback.print_exc()
                st.stop()
                
        # 3. Orchestrator 초기화
        st.session_state.orchestrator = AgentOrchestrator(google_api_key)
        
    # 4. 세션 상태 변수 초기화 (사용자 UI 흐름용)
    if "step" not in st.session_state:
        st.session_state.step = "get_merchant_name" 
        st.session_state.messages = []
        st.session_state.merchant_id = None
        st.session_state.merchant_name = None
        st.session_state.profile_data = None
        st.session_state.consultation_result = None

def restart_consultation():
    """처음으로 돌아가기 (세션 초기화)"""
    keys_to_reset = ["step", "merchant_name", "merchant_id", "profile_data", "messages", "consultation_result"]
    for key in keys_to_reset:
        if key in st.session_state:
            del st.session_state[key]
    # initialize_session()은 main()에서 다시 호출됨
    
def render_sidebar():
    """사이드바 렌더링 (처음으로 돌아가기 버튼)"""
    with st.sidebar:
        st.markdown("<h3 style='text-align: center;'>Synapse</h3>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center;'>2025 Big Contest</p>", unsafe_allow_html=True)
        st.write("")
        col1, col2, col3 = st.columns([1,2,1])
        with col2:
            if st.button('처음으로 돌아가기', key='restart_button', use_container_width=True):
                restart_consultation()
                st.rerun()

def render_get_merchant_name_step():
    """UI 1단계: 가맹점 검색 및 선택"""
    st.subheader("컨설팅 받을 가게를 검색해주세요.")
    search_query = st.text_input("가게 이름 또는 가맹점 ID 검색", placeholder="예: 메가, 003AC99735 등")

    if search_query:
        mask = (
            merchant_df['가맹점명'].str.contains(search_query, case=False, na=False) |
            merchant_df['가맹점ID'].str.contains(search_query, case=False, na=False)
        )
        
        search_results = merchant_df[mask].copy()

        if not search_results.empty:
            search_results['display'] = search_results['가맹점명'] + " (" + search_results['가맹점ID'] + ")"
            options = ["선택해주세요..."] + search_results['display'].tolist()
            selected_display_name = st.selectbox("가게를 선택하세요:", options)

            if selected_display_name != "선택해주세요...":
                
                try:
                    selected_row = search_results[search_results['display'] == selected_display_name].iloc[0]
                    selected_merchant_id = selected_row['가맹점ID']
                    selected_merchant_name = selected_row['가맹점명']
                    button_label = f"'{selected_merchant_name}' 분석 정보 보기"
                    is_selection_valid = True
                except (IndexError, KeyError):
                    st.error("선택한 가게 정보를 찾는 데 실패했습니다. 다시 시도해주세요.")
                    button_label = "분석 정보 보기"
                    is_selection_valid = False

                if st.button(button_label, disabled=not is_selection_valid, type="primary"):
                    with st.spinner(f"'{selected_merchant_name} ({selected_merchant_id})' 가게 정보를 분석 중입니다..."):
                        orchestrator = st.session_state.orchestrator
                        profile_data = orchestrator.get_store_profile_only(merchant_id=selected_merchant_id)

                        if "error" in profile_data:
                            st.error(f"오류: {profile_data['error']}")
                        else:
                            st.session_state.merchant_name = selected_merchant_name
                            st.session_state.merchant_id = selected_merchant_id 
                            st.session_state.profile_data = profile_data
                            st.session_state.step = "show_profile_and_chat"
                            st.rerun()
        else:
            st.warning("검색 결과가 없습니다. 다른 검색어를 입력해주세요.")

def render_show_profile_and_chat_step():
    """UI 2단계: 프로필 확인 및 AI 채팅"""
    st.subheader(f"✅ '{st.session_state.merchant_name}' 가게 분석 완료")
    with st.expander("📊 상세 데이터 분석 리포트 보기", expanded=True):
        try:
            display_merchant_profile(st.session_state.profile_data)
        except Exception as e:
            st.error(f"프로필 시각화 중 오류 발생: {e}")
            print(f"--- [Visualize ERROR]: {e}\n{traceback.format_exc()}")

    st.divider()
    st.subheader("💬 AI 컨설턴트와 상담을 시작하세요.")
    
    st.info("가게 분석 정보를 바탕으로 궁금한 점을 질문해보세요. (예: '20대 여성 고객을 늘리고 싶어요')")

    # 채팅 기록 표시
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # 채팅 입력
    if prompt := st.chat_input("요청사항을 입력하세요..."):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        with st.chat_message("assistant"):
            with st.spinner("AI 컨설턴트가 답변을 생성 중입니다...(최대 1~2분)"):
                orchestrator = st.session_state.orchestrator
                result = orchestrator.execute_plan(
                    user_query=prompt,
                    merchant_name=st.session_state.merchant_name,
                    merchant_id=st.session_state.merchant_id,
                    profile_data=st.session_state.profile_data
                )

                if "error" in result:
                    response = f"오류 발생: {result['error']}"
                elif "final_response" in result:
                    response = result["final_response"]
                    st.session_state.consultation_result = result
                else:
                    response = "알 수 없는 오류가 발생했습니다."

                st.markdown(response)
        st.session_state.messages.append({"role": "assistant", "content": response})

def main():
    st.title("🎈 지역축제 부스 참여 AI 컨설턴트")
    st.markdown("신한카드 빅데이터와 AI 에이전트를 활용하여, 사장님 가게를 분석하여 꼭 맞는 지역 축제를 추천하고 맞춤형 마케팅 전략을 제시합니다.")
    
    initialize_session()
    render_sidebar()

    # 세션 상태(step)에 따라 다른 UI 렌더링
    if st.session_state.step == "get_merchant_name":
        render_get_merchant_name_step()
    elif st.session_state.step == "show_profile_and_chat":
        render_show_profile_and_chat_step()

if __name__ == "__main__":
    main()