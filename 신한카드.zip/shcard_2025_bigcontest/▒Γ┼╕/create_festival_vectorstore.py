import pandas as pd
import os
import traceback
from pathlib import Path
from datetime import datetime
import time

from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.docstore.document import Document

# --- 1. 축제 데이터 로더
def _load_and_process_festivals_for_indexing():
    print("--- [Indexer] 'festival_df.csv' 로딩 및 전처리 시작... ---")
    try:
        # 이 스크립트는 프로젝트 루트에 있다고 가정
        project_root = Path(__file__).resolve().parent
        file_path = project_root / 'data' / 'festival_df.csv'
        if not file_path.exists():
            raise FileNotFoundError(f"데이터 파일을 찾을 수 없습니다: {file_path}")
        
        df = pd.read_csv(file_path)
        if df.empty:
            raise ValueError("'festival_df.csv' 파일에 데이터가 없습니다.")

        date_column_name = '2025_기간'
        if date_column_name not in df.columns:
             raise KeyError(f"'{date_column_name}' 컬럼을 festival_df.csv 파일에서 찾을 수 없습니다.")

        df['date'] = df[date_column_name].astype(str).str.split('~').str[0].str.strip()
        df['date'] = pd.to_datetime(df['date'], errors='coerce').dt.strftime('%Y-%m-%d')
        df.dropna(subset=['date'], inplace=True)

        if df.empty:
            raise ValueError("처리할 수 있는 유효한 날짜 데이터가 '2025_기간' 컬럼에 없습니다.")
        
        df.rename(columns={'축제명': 'festival_name', '소개': 'description'}, inplace=True)
        
        print(f"--- [Indexer] 'festival_df.csv' 로딩 성공. {len(df)}개 축제 발견 ---")
        return df.to_dict('records')
        
    except Exception as e:
        print(f"--- [Indexer CRITICAL] 'festival_df.csv' 로딩 실패: {e}\n{traceback.format_exc()} ---")
        return None

# --- 2. 임베딩 모델 준비 (knowledge_base.py에서 가져옴) ---
def get_embeddings_model():
    print("--- [Indexer] HuggingFace 임베딩 모델 로딩 시작... ---")
    model_name = "dragonkue/BGE-m3-ko"
    model_kwargs = {'device': 'cpu'} # CPU 사용
    encode_kwargs = {'normalize_embeddings': True} # BGE 모델은 정규화 권장
    
    embeddings = HuggingFaceEmbeddings(
        model_name=model_name,
        model_kwargs=model_kwargs,
        encode_kwargs=encode_kwargs
    )
    print("--- [Indexer] HuggingFace 임베딩 모델 로딩 완료 ---")
    return embeddings

# --- 3. 벡터 스토어 구축 및 저장 ---
def build_and_save_vector_store():
    start_time = time.time()
    
    # 1. 축제 데이터 로드
    festivals = _load_and_process_festivals_for_indexing()
    if not festivals:
        print("--- [Indexer ERROR] 축제 데이터가 없어 인덱싱을 중단합니다.")
        return

    # 2. 임베딩 모델 로드
    embeddings = get_embeddings_model()

    # 3. LangChain Document 객체 생성 (요청사항: 축제 문서화)
    documents = []
    print("--- [Indexer] 축제 정보 -> 문서(Document) 변환 시작 ---")
    for festival in festivals:
        # 임베딩에 사용될 텍스트 (축제명, 소개, 지역, 키워드)
        content = (
            f"축제명: {festival.get('festival_name', '')}\n"
            f"소개: {festival.get('description', '')}\n"
            f"지역: {festival.get('지역', '')}\n"
            f"키워드: {festival.get('키워드', '')}"
        )
        
        # 메타데이터 (나중에 검색 시 원본 데이터를 찾기 위함)
        # 중요: 'festival_name'이 있어야 나중에 원본 dict와 매칭 가능
        metadata = {
            "festival_name": festival.get('festival_name'),
            "region": festival.get('지역'),
            "date": festival.get('date'),
        }
        documents.append(Document(page_content=content, metadata=metadata))
    
    print(f"--- [Indexer] 문서 변환 완료. 총 {len(documents)}개 문서 생성 ---")

    # 4. FAISS 벡터 스토어 생성
    print("--- [Indexer] FAISS 벡터 스토어 생성 시작 (시간이 걸릴 수 있습니다)... ---")
    vector_store = FAISS.from_documents(documents, embeddings)
    print("--- [Indexer] FAISS 벡터 스토어 생성 완료 ---")

    # 5. 로컬에 저장
    project_root = Path(__file__).resolve().parent
    save_path = Path('./festival_retriever')    
    
    # vector_store 폴더가 없으면 생성
    os.makedirs(save_path.parent, exist_ok=True)
    
    vector_store.save_local(str(save_path))
    
    end_time = time.time()
    print("=" * 50)
    print(f"🎉 성공! FAISS 벡터 스토어를 생성하여 '{save_path}'에 저장했습니다.")
    print(f"총 소요 시간: {end_time - start_time:.2f}초")
    print("=" * 50)

if __name__ == "__main__":
    build_and_save_vector_store()