# modules/knowledge_base.py

import os
import streamlit as st
from pathlib import Path
from langchain_core.tools import tool
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings 
import traceback 

@st.cache_resource
def _load_embedding_model():
    """
    임베딩 모델을 별도 함수로 분리하여 캐싱 (FAISS 로드 시 재사용)
    """
    try:
        print("--- [Cache] HuggingFace 임베딩 모델 최초 로딩 시작 ---")
        model_name = "dragonkue/BGE-m3-ko"
        model_kwargs = {'device': 'cpu'}
        encode_kwargs = {'normalize_embeddings': True}

        embeddings = HuggingFaceEmbeddings(
            model_name=model_name,
            model_kwargs=model_kwargs,
            encode_kwargs=encode_kwargs
        )
        print("--- [Cache] HuggingFace 임베딩 모델 로딩 성공 ---")
        return embeddings
    except Exception as e:
        print(f"--- [CRITICAL ERROR] 임베딩 모델 로딩 실패: {e} ---")
        traceback.print_exc()
        st.error(f"임베딩 모델('dragonkue/BGE-m3-ko') 로딩 중 심각한 오류가 발생했습니다: {e}")
        return None

# --- 'retriever'가 아닌 (vector_store, embeddings)를 반환하도록 변경 ---
@st.cache_resource
def load_festival_vector_store():
    """
    (수정) 축제 정보 FAISS Vector Store와 임베딩 모델을 로드하여 튜플로 반환합니다.
    (filtering.py에서 벡터 검색 시 vector_store 객체가 직접 필요합니다.)
    """
    try:
        embeddings = _load_embedding_model()
        if embeddings is None:
            raise Exception("임베딩 모델 로드에 실패하여 Vector Store를 로드할 수 없습니다.")

        project_root = Path(__file__).resolve().parent.parent
        faiss_index_path = project_root / 'vectorstore' / 'faiss_festivals'
        
        if not faiss_index_path.exists():
            print(f"--- [CRITICAL ERROR] '축제' FAISS 인덱스 폴더를 찾을 수 없습니다: {faiss_index_path}")
            print("--- [Info] 'data_loader.py'의 main()을 실행하여 인덱스를 생성해야 합니다. ---")
            st.error(f"'축제' FAISS 인덱스({faiss_index_path})를 찾을 수 없습니다. 인덱스 생성 스크립트를 실행해주세요.")
            return None, None # 튜플 반환

        vector_store = FAISS.load_local(
            str(faiss_index_path),
            embeddings,
            allow_dangerous_deserialization=True 
        )
        
        print("--- [Cache] '축제' FAISS Vector Store 로딩 성공 (HuggingFace) ---")
        return vector_store, embeddings # 튜플 반환

    except Exception as e:
        print(f"--- [CRITICAL ERROR] '축제' Vector Store 로딩 실패: {e} ---")
        traceback.print_exc()
        st.error(f"'축제' Vector Store 로딩 중 심각한 오류가 발생했습니다: {e}")
        return None, None # 튜플 반환

# --- [수정] 'retriever' 로드 함수 (마케팅용) ---
@st.cache_resource
def load_retriever():
    """
    '마케팅 전략' FAISS Vector Store를 로드하여 'Retriever' 객체로 반환합니다.
    (RAG 파이프라인 전용)
    """
    try:
        embeddings = _load_embedding_model()
        if embeddings is None:
            raise Exception("임베딩 모델 로드에 실패하여 Retriever를 로드할 수 없습니다.")

        project_root = Path(__file__).resolve().parent.parent
        faiss_index_path = project_root / 'vectorstore' / 'faiss_marketing' # 마케팅 인덱스 경로
        
        if not faiss_index_path.exists():
            print(f"--- [CRITICAL ERROR] '마케팅' FAISS 인덱스 폴더를 찾을 수 없습니다: {faiss_index_path}")
            st.error(f"'마케팅' FAISS 인덱스({faiss_index_path})를 찾을 수 없습니다. 인덱스 생성 스크립트를 실행해주세요.")
            return None

        vector_store = FAISS.load_local(
            str(faiss_index_path),
            embeddings,
            allow_dangerous_deserialization=True 
        )
        
        retriever = vector_store.as_retriever(search_kwargs={'k': 3})
        
        print("--- [Cache] '마케팅' FAISS Vector Store 로딩 성공 (HuggingFace) ---")
        return retriever

    except Exception as e:
        print(f"--- [CRITICAL ERROR] '마케팅' Retriever 로딩 실패: {e} ---")
        traceback.print_exc()
        st.error(f"'마케팅' Retriever 로딩 중 심각한 오류가 발생했습니다: {e}")
        return None


@tool
def search_contextual_marketing_strategy(store_profile: dict, user_query: str) -> str:
    """
    가게 프로필과 사용자 질문의 맥락을 이해하여, RAG 파이프라인을 통해 가장 관련성 높은 맞춤형 마케팅 전략을 검색합니다.
    """
    marketing_retriever = load_retriever() # 마케팅 Retriever 로드

    if marketing_retriever is None:
        return "오류: 마케팅 전략 Retriever가 로드되지 않았습니다. 서버 로그 및 Streamlit 화면의 오류 메시지를 확인해주세요."

    try:
        profile_summary = f"주요 고객은 {store_profile.get('핵심연령대', '')} {store_profile.get('핵심고객', '')}이며, 업종은 {store_profile.get('업종', '')}입니다."
        contextual_query = f"[가게 정보]\n{profile_summary}\n\n[사장님 질문]\n{user_query}\n\n위 정보를 바탕으로 이 가게에 가장 적합한 마케팅 전략 3가지를 알려주세요."

        docs = marketing_retriever.invoke(contextual_query)
        
        strategy = "\n\n---\n\n".join([doc.page_content for doc in docs])
        
        if not strategy:
            return "관련 마케팅 전략을 찾지 못했습니다."
            
        return strategy
        
    except Exception as e:
        print(f"--- [ERROR] search_contextual_marketing_strategy 실패: {e} ---")
        traceback.print_exc()
        return f"마케팅 전략 검색 중 오류 발생: {e}"