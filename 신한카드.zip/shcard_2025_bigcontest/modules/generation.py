# modules/generation.py

import os
import json
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
import traceback # [추가]

def format_final_response(
    merchant_name: str,
    user_query: str,
    profile_data: dict,
    recommendations: list,
    scoring_criteria: dict,
    marketing_strategy: str
) -> str:
    """
    (수정됨) LLM을 직접 호출하여, 모든 분석 데이터를 취합해
    최종 컨설팅 보고서를 생성합니다.
    """
    
    # 1. LLM 초기화 (orchestrator에서 llm 객체를 받지 않고, 여기서 직접 생성)
    try:
        google_api_key = os.environ.get("GOOGLE_API_KEY")
        if not google_api_key:
            return "오류: GOOGLE_API_KEY가 설정되지 않아 보고서를 생성할 수 없습니다."
        
        # 답변 생성용 LLM
        llm = ChatGoogleGenerativeAI(
            model="gemini-2.5-flash", 
            google_api_key=google_api_key, 
            temperature=0.4
        )
    except Exception as e:
        print(f"--- [Generation ERROR] LLM 초기화 실패: {e} ---")
        traceback.print_exc()
        return f"오류: 보고서 생성 LLM을 초기화하는 중 오류가 발생했습니다: {e}"

    
    # 2. 추천 축제 정보 포맷팅
    recommendation_details = ""
    if not recommendations:
        recommendation_details = "추천할 만한 축제를 찾지 못했습니다."
    else:
        for i, rec in enumerate(recommendations):
            
            # --- [ ⚠️ 여기가 수정 지점 ⚠️ ] ---
            # 'final_score' -> 'hybrid_score'로 변경
            # (추가) {rec['hybrid_score']:.1f} 로 수정하여 소수점 첫째 자리까지 표시
            recommendation_details += (
                f"\n### 🏆 추천 {i+1}순위: {rec['festival_name']} (최종 점수: {rec['hybrid_score']:.1f}점)\n"
                f"- **추천 근거:** {rec['llm_reason']}\n"
                f"- **축제 위치:** {rec['metadata'].get('지역', '정보 없음')}\n"
                f"- **축제 기간 (2025년 기준):** {rec['metadata'].get('2025_기간', '정보 없음')}\n"
            )
            # --- [ 수정 완료 ] ---

    # 3. 프롬프트 생성
    prompt = f"""
    당신은 신한카드 빅데이터와 AI를 활용하는 전문 상권 분석 컨설턴트입니다.
    주어진 정보를 종합하여 가게 사장님을 위한 최종 컨설팅 보고서를 '마크다운(Markdown)' 형식으로 작성해주세요.

    [분석 대상 및 요청사항]
    - 가게 이름: {merchant_name}
    - 사장님 요청사항: "{user_query}"

    [AI 시스템 분석 데이터]
    1. 가게 프로필 요약: {json.dumps(profile_data.get('store_profile', {}).get('자동추출특징', {}), ensure_ascii=False, indent=2)}
    
    2. 맞춤형 축제 추천 (Top 3):
    {recommendation_details}

    3. 축제 선정 기준 (AI가 생성한 동적 채점 기준):
    {json.dumps(scoring_criteria, ensure_ascii=False, indent=2)}

    4. 맞춤형 마케팅 전략 (RAG 검색 결과):
    {marketing_strategy}

    [보고서 작성 가이드]
    1. **인사:** 사장님께 친근하게 인사하며 컨설팅 보고서의 목적을 설명합니다.
    2. **축제 추천:** 'AI 시스템 분석 데이터'의 '2. 맞춤형 축제 추천' 섹션을 기반으로, 왜 이 축제들을 추천했는지 알기 쉽게 설명합니다. '선정 과정'과 '최종 점수'를 언급하여 신뢰도를 높입니다.
    3. **마케팅 전략:** '4. 맞춤형 마케팅 전략'을 기반으로, 추천된 축제에서 활용할 수 있는 구체적인 액션 플랜을 2~3가지 제시합니다.
    4. **데이터 기반 조언:** '1. 가게 프로필 요약'을 바탕으로, 사장님이 평소에 놓칠 수 있는 부분이나 강화해야 할 점을 조언합니다.
    5. **마무리:** 긍정적인 응원 메시지로 보고서를 마무리합니다.
    
    [보고서 시작]
    """
    
    # 4. LLM 호출
    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        return response.content
    except Exception as e:
        print(f"--- [Generation ERROR] 최종 보고서 생성 실패: {e} ---")
        traceback.print_exc()
        return f"오류: 최종 보고서를 생성하는 중 오류가 발생했습니다: {e}"