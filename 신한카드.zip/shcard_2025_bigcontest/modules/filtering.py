# modules/filtering.py

import json
import re
import traceback
from typing import List, Dict, Any, Optional, Tuple

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.messages import HumanMessage
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document

from modules.knowledge_base import load_festival_vector_store


# ---------------------------- LLM 초기화 ----------------------------
def _init_llm(temperature: float = 0.0) -> ChatGoogleGenerativeAI:
    """LLM을 초기화합니다."""
    try:
        # 참고: generation.py 에서는 gemini-1.5-flash-latest를 사용했으나,
        # 여기서는 안정적인 gemini-1.5-flash 버전을 사용합니다. (필요시 통일)
        return ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=temperature)
    except Exception as e:
        # LLM 초기화 실패는 심각한 오류이므로 예외를 발생시킵니다.
        raise RuntimeError(f"LLM 초기화 실패: {e}")


# ---------------------------- 1단계: 의미 기반 쿼리 생성 ----------------------------
def rewrite_query_with_llm(
    store_profile: dict, 
    user_query: str, 
    llm: ChatGoogleGenerativeAI
) -> str:
    """
    가게 프로필과 사용자 쿼리를 기반으로 FAISS 검색에 가장 적합한
    '의미 검색용 쿼리'를 LLM을 통해 재작성합니다.
    """
    print("--- [Filter] 1. LLM으로 의미 검색용 쿼리 재작성 시작 ---")
    
    # 가게 프로필에서 핵심 특징 추출
    profile_summary = store_profile.get('store_profile', {}).get('자동추출특징', {})
    if not profile_summary:
        profile_summary = {
            "업종": store_profile.get('store_profile', {}).get('업종', '정보 없음'),
            "핵심고객": f"{store_profile.get('store_profile', {}).get('핵심연령대', '')} {store_profile.get('store_profile', {}).get('핵심고객', '')}"
        }

    prompt = f"""
    당신은 한국 지역 축제 데이터베이스에서 검색할 검색 쿼리를 생성하는 전문가입니다.
    가게 프로필과 사장님의 요청사항을 바탕으로, 이 가게가 참여하면 좋을 만한 축제의 특징을 요약한 '키워드 문장'을 1줄로 생성해주세요.

    [가게 프로필]
    {json.dumps(profile_summary, ensure_ascii=False, indent=2)}

    [사장님 요청사항]
    "{user_query}"

    [생성 가이드]
    - 가게의 주요 고객층(예: 20대 여성, 30대 가족)과 가게 업종(예: 디저트 카페, 한식 주점)을 반드시 포함하세요.
    - 사장님의 요청사항(예: 매출 증대, 신규 고객 확보)을 반영하세요.
    - 예시: "서울 마포구에서 20대 여성 대상 디저트 카페를 운영 중이며, SNS 홍보 및 신규 고객 확보에 적합한 축제"
    - 다른 설명 없이 '키워드 문장'만 생성해주세요.

    [검색 쿼리]
    """

    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        rewritten_query = response.content.strip()
        
        # LLM이 추가적인 문장을 생성했을 경우 첫 줄만 사용
        rewritten_query = rewritten_query.split('\n')[0]
        
        print(f"--- [Filter] 1. 재작성된 쿼리: {rewritten_query} ---")
        return rewritten_query
    
    except Exception as e:
        print(f"--- [Filter WARNING] 1. 쿼리 재작성 실패: {e}. 원본 쿼리 사용. ---")
        traceback.print_exc()
        return user_query # 실패 시 원본 쿼리 반환


# ---------------------------- 2단계: FAISS 벡터 검색 ----------------------------
def search_faiss_candidates(
    query: str, 
    vector_store: FAISS, 
    k: int = 10
) -> List[Tuple[Document, float]]:
    """FAISS 벡터 저장소에서 유사도 높은 축제 후보 K개를 검색합니다."""
    print(f"--- [Filter] 2. FAISS 벡터 검색 시작 (K={k}) ---")
    try:
        # similarity_search_with_score는 (Document, L2거리)를 반환
        candidates = vector_store.similarity_search_with_score(query, k=k)
        if not candidates:
            print("--- [Filter WARNING] 2. FAISS 검색 결과 없음 ---")
            return []
        
        print(f"--- [Filter] 2. FAISS 검색 완료. 후보 {len(candidates)}개 찾음 ---")
        return candidates
        
    except Exception as e:
        print(f"--- [Filter CRITICAL] 2. FAISS 검색 실패: {e} ---")
        traceback.print_exc()
        return []


# ---------------------------- 3단계: 동적 채점 기준 생성 ----------------------------

# LLM이 생성한 기준이 유효한지 검증하는 내부 함수
def _validate_scoring_criteria(criteria_list: List[Dict[str, Any]]) -> bool:
    """LLM이 생성한 채점 기준 리스트의 유효성을 검사합니다."""
    if not isinstance(criteria_list, list) or not criteria_list:
        return False
    
    total_importance = 0
    for item in criteria_list:
        if not isinstance(item, dict):
            return False
        if "기준명" not in item or "중요도" not in item:
            return False
        if not isinstance(item["기준명"], str) or not item["기준명"]:
            return False
        
        importance = item["중요도"]
        # --- [오류 수정 지점] ---
        # "중요도": 12 와 같은 잘못된 값을 여기서 차단합니다.
        # 규칙: 중요도는 반드시 1~10 사이의 정수여야 합니다.
        if not isinstance(importance, int) or not (1 <= importance <= 10):
            print(f"--- [Validation] 유효성 검사 실패: 중요도 값이 1~10 범위를 벗어남 (값: {importance}) ---")
            return False
        total_importance += importance

    # 중요도 총합이 0이 아닌지 확인 (모든 중요도가 0일 수는 없음)
    return total_importance > 0

# Fallback으로 사용할 기본 채점 기준
FALLBACK_SCORING_CRITERIA = [
    {"기준명": "가게-축제 타겟 일치도", "중요도": 10},
    {"기준명": "예상 방문객 수 및 화제성", "중요도": 8},
    {"기준명": "가게 업종과의 시너지", "중요도": 6},
    {"기준명": "신규 고객 확보 가능성", "중요도": 5},
]

def create_dynamic_scoring_criteria(
    store_profile: dict, 
    user_query: str, 
    llm: ChatGoogleGenerativeAI
) -> List[Dict[str, Any]]:
    """
    가게 프로필과 사용자 쿼리를 기반으로 LLM을 통해
    축제 평가를 위한 동적 채점 기준(JSON)을 생성합니다.
    """
    print("--- [Filter] 3. LLM으로 동적 채점 기준 생성 시작 ---")
    
    profile_summary = store_profile.get('store_profile', {}).get('자동추출특징', {})

    # --- [수정] 프롬프트 강화 (Prompt Hardening) ---
    # LLM이 "중요도": 12 와 같은 잘못된 값을 반환하지 않도록 규칙을 매우 강력하게 명시합니다.
    prompt = f"""
    당신은 가게의 특성과 사장님의 요청에 맞춰 축제 추천 시스템의 '채점 기준'을 생성하는 AI입니다.
    주어진 정보를 바탕으로, 축제를 평가할 4가지 핵심 기준과 각 기준의 '중요도' 점수를 JSON 리스트 형식으로 생성해주세요.

    [가게 프로필]
    {json.dumps(profile_summary, ensure_ascii=False, indent=2)}

    [사장님 요청사항]
    "{user_query}"

    [출력 형식 및 규칙]
    - 반드시 4개의 기준을 생성해야 합니다.
    - 반드시 아래와 같은 JSON 리스트 형식을 준수해야 합니다.
    - "기준명": 20자 이내의 간결한 한글 기준
    - "중요도": **반드시 1점에서 10점 사이의 정수(Integer)**여야 합니다.
    - **규칙 위반 (중요도 10 초과):** 절대로 "중요도"에 10을 초과하는 값(예: 11, 12, 15)을 할당하지 마세요.
    - **규칙 위반 (중요도 1 미만):** 절대로 "중요도"에 1 미만의 값(예: 0, 0.5)을 할당하지 마세요.
    - 다른 설명 없이 JSON 코드 블록(```json ... ```)만 응답하세요.

    [좋은 예시 (규칙 준수)]
    ```json
    [
      {{
        "기준명": "핵심 고객(20대 여성) 일치도",
        "중요도": 10
      }},
      {{
        "기준명": "디저트 업종 시너지",
        "중요도": 8
      }},
      {{
        "기준명": "SNS 홍보 및 화제성",
        "중요도": 7
      }},
      {{
        "기준명": "신규 고객 유입 가능성",
        "중요도": 5
      }}
    ]
    ```
    
    [나쁜 예시 (규칙 위반 - 중요도 12)]
    ```json
    [
      {{
        "기준명": "20대 여성 타겟 일치도",
        "중요도": 12 
      }},
      ...
    ]
    ```
    """
    # --- [수정] 프롬프트 강화 끝 ---

    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        content = response.content.strip()
        
        # 마크다운 코드 블록(```json ... ```) 제거
        match = re.search(r'```json\s*([\s\S]*?)\s*```', content)
        if match:
            json_str = match.group(1)
        else:
            json_str = content # 코드 블록이 없으면 전체를 JSON으로 가정

        criteria_list = json.loads(json_str)

        if _validate_scoring_criteria(criteria_list):
            print(f"--- [Filter] 3. LLM 기반 동적 기준 생성 성공 (기준 {len(criteria_list)}개) ---")
            return criteria_list
        else:
            # 유효성 검사 실패 시 (예: "중요도": 12)
            print(f"--- [Filter WARNING] 3. LLM이 유효한 기준을 생성하지 못했습니다 (결과: {json_str}). Fallback 기준을 사용합니다. ---")
            return FALLBACK_SCORING_CRITERIA

    except Exception as e:
        print(f"--- [Filter WARNING] 3. 동적 기준 생성 실패 (오류: {e}). Fallback 기준을 사용합니다. ---")
        traceback.print_exc()
        return FALLBACK_SCORING_CRITERIA


# ---------------------------- 4단계: 후보군 일괄 평가 (속도 개선) ----------------------------

def _parse_batch_evaluation_response(response_content: str, candidates: List[Document]) -> List[Dict[str, Any]]:
    """LLM의 일괄 평가 응답(JSON 배열 문자열)을 파싱하고 원본 문서와 매핑합니다."""
    
    # 1. 응답에서 JSON 코드 블록 추출
    match = re.search(r'```json\s*([\s\S]*?)\s*```', response_content)
    if match:
        json_str = match.group(1)
    else:
        json_str = response_content
        
    # 2. JSON 파싱
    try:
        evaluations = json.loads(json_str)
        if not isinstance(evaluations, list):
            raise ValueError("LLM 응답이 JSON 리스트 형식이 아닙니다.")
            
    except Exception as e:
        print(f"--- [Filter CRITICAL] 4. (Batch) LLM 응답 파싱 실패: {e}. Fallback 평가를 생성합니다. ---")
        # LLM 응답이 완전히 깨졌을 경우, 후보 리스트를 기반으로 점수 없는 기본값을 생성
        evaluations = []
        for doc in candidates:
            evaluations.append({
                "festival_name": doc.metadata.get("festival_name") or doc.metadata.get("축제명", "이름 없음"),
                "total_score": 0,
                "reason": "LLM 응답 파싱 오류로 자동 생성된 Fallback 데이터입니다."
            })

    # 3. 원본 문서(candidates)와 LLM 평가 결과(evaluations)를 매핑
    #    LLM이 순서를 지키거나 일부를 누락했을 수 있으므로, festival_name을 기준으로 매핑합니다.
    
    candidate_map = {
        (doc.metadata.get("festival_name") or doc.metadata.get("축제명")): doc 
        for doc in candidates
    }
    
    final_results = []
    
    # LLM이 생성한 평가 결과를 기준으로 루프
    for eval_item in evaluations:
        if not isinstance(eval_item, dict):
            continue # 유효하지 않은 항목 스킵
            
        name = eval_item.get("festival_name")
        if name in candidate_map:
            doc = candidate_map[name]
            
            # 원본 문서 정보와 LLM 평가 정보를 결합
            combined_result = {
                "document": doc,
                "metadata": doc.metadata,
                "festival_name": name,
                "llm_score": float(eval_item.get("total_score", 0)),
                "llm_reason": eval_item.get("reason", "평가 근거 없음"),
            }
            final_results.append(combined_result)
            
            del candidate_map[name] # 매핑된 항목 제거

    # LLM이 누락한 후보가 있는지 확인 (candidate_map에 남아있음)
    if candidate_map:
        print(f"--- [Filter WARNING] 4. (Batch) LLM이 {len(candidate_map)}개의 후보를 평가에서 누락했습니다. ---")
        for name, doc in candidate_map.items():
             final_results.append({
                "document": doc,
                "metadata": doc.metadata,
                "festival_name": name,
                "llm_score": 0.0,
                "llm_reason": "LLM이 평가 결과에서 누락함.",
            })

    return final_results


# --- [추가] 속도 개선을 위한 핵심 함수 (일괄 평가) ---
def evaluate_candidates_in_batch(
    candidates: List[Document],
    scoring_criteria: List[Dict[str, Any]],
    store_profile: dict,
    user_query: str,
    llm: ChatGoogleGenerativeAI
) -> List[Dict[str, Any]]:
    """
    (신규) LLM을 *단 한 번* 호출하여 모든 축제 후보(N개)를 일괄 평가합니다.
    N+1 문제를 해결하여 속도를 대폭 향상시킵니다.
    """
    print(f"--- [Filter] 4. (Batch) LLM으로 후보 축제 {len(candidates)}개 일괄 평가 시작 ---")

    # 1. 평가 대상 축제 리스트를 JSON 형식으로 변환
    candidate_list_json = []
    for doc in candidates:
        candidate_list_json.append({
            "festival_name": doc.metadata.get("festival_name") or doc.metadata.get("축제명"),
            "description": doc.page_content, # Document의 본문 (축제 소개)
            "location": doc.metadata.get("지역"),
            "date": doc.metadata.get("2025_기간"),
        })

    # 2. 가게 프로필 요약
    profile_summary = store_profile.get('store_profile', {}).get('자동추출특징', {})

    # 3. 일괄 평가용 프롬프트
    prompt = f"""
    당신은 신한카드 빅데이터 기반 상권 분석가입니다.
    주어진 [가게 프로필]과 [사장님 요청]을 바탕으로, 아래 [채점 기준]에 따라 [축제 후보 리스트]에 있는 **각 축제**를 평가해주세요.

    [가게 프로필]
    {json.dumps(profile_summary, ensure_ascii=False, indent=2)}

    [사장님 요청]
    "{user_query}"

    [채점 기준]
    {json.dumps(scoring_criteria, ensure_ascii=False, indent=2)}

    [축제 후보 리스트 (평가 대상)]
    {json.dumps(candidate_list_json, ensure_ascii=False, indent=2)}

    [과제]
    1. [축제 후보 리스트]의 **모든 축제**에 대해 [채점 기준]을 적용하여 평가를 수행하세요.
    2. 각 기준의 '중요도'를 가중치로 사용하여 각 축제의 'total_score' (100점 만점)를 계산하세요.
       (예: (기준1 점수 * 기준1 중요도) + ... / (모든 중요도 합계) * 10)
    3. 각 축제별로 이 점수를 준 'reason' (핵심 근거)을 2~3줄로 요약 작성하세요.
    4. **모든 축제**의 평가 결과를 **JSON 리스트** 형식으로 반환하세요.
    
    [출력 형식 (반드시 JSON 코드 블록으로만 응답)]
    ```json
    [
      {{
        "festival_name": "첫 번째 축제 이름",
        "total_score": 85.5,
        "reason": "20대 여성 타겟이 가게의 핵심 고객과 정확히 일치하며, 디저트 업종과의 시너지가 높을 것으로 예상됩니다. SNS 홍보 효과도 기대됩니다."
      }},
      {{
        "festival_name": "두 번째 축제 이름",
        "total_score": 60.0,
        "reason": "가족 단위 방문객이 많아 가게의 주 타겟(20대)과는 다소 거리가 있으나, 방문객 수가 많아 매출 증대는 기대할 수 있습니다."
      }},
      ...
    ]
    ```
    """

    try:
        response = llm.invoke([HumanMessage(content=prompt)])
        # LLM의 JSON 문자열 응답을 파싱하고 원본 문서와 매핑
        evaluated_results = _parse_batch_evaluation_response(response.content, candidates)
        print(f"--- [Filter] 4. (Batch) LLM 일괄 평가 완료. {len(evaluated_results)}개 평가됨 ---")
        return evaluated_results

    except Exception as e:
        print(f"--- [Filter CRITICAL] 4. (Batch) LLM 일괄 평가 중 심각한 오류 발생: {e} ---")
        traceback.print_exc()
        # 치명적 오류 발생 시, 빈 평가 리스트 반환
        return [
            {
                "document": doc,
                "metadata": doc.metadata,
                "festival_name": doc.metadata.get("festival_name") or doc.metadata.get("축제명"),
                "llm_score": 0.0,
                "llm_reason": f"LLM 평가 중 오류 발생: {e}",
            }
            for doc in candidates
        ]


# ---------------------------- (참고) 기존 개별 평가 함수 (현재 미사용) ----------------------------
def evaluate_candidate_with_llm(
    doc: Document,
    scoring_criteria: List[Dict[str, Any]],
    store_profile: dict,
    user_query: str,
    llm: ChatGoogleGenerativeAI
) -> Dict[str, Any]:
    """
    (기존 함수 - 속도 저하의 원인)
    LLM을 호출하여 *단일* 축제 후보(doc)를 평가합니다.
    """
    # ... (기존 evaluate_candidate_with_llm 함수의 코드는 생략) ...
    # 이 함수는 run_festival_recommendation에서 더 이상 호출되지 않습니다.
    pass


# ---------------------------- 5단계: 하이브리드 스코어링 및 최종 정렬 ----------------------------
def calculate_hybrid_scores(
    evaluated_candidates: List[Dict[str, Any]],
    emb_scores_map: Dict[str, float],
    weights: Dict[str, float] = {"embedding": 0.4, "llm": 0.6}
) -> List[Dict[str, Any]]:
    """
    FAISS의 임베딩 유사도(emb_score)와 LLM의 정성 평가 점수(llm_score)를
    가중 합산하여 최종 하이브리드 점수를 계산합니다.
    """
    print("--- [Filter] 5. 하이브리드 스코어링 및 최종 정렬 시작 ---")
    
    final_list = []
    
    for item in evaluated_candidates:
        name = item.get("festival_name")
        
        # 1. 임베딩 점수 (0~1 정규화)
        # emb_scores_map에서 해당 축제 이름으로 점수 조회
        emb_score_raw = emb_scores_map.get(name, 0.0)
        emb_score = emb_score_raw * 100 # (0~1 사이 점수를 100점 만점으로 변환)
        
        # 2. LLM 평가 점수 (0~100)
        llm_score = item.get("llm_score", 0.0)
        
        # 3. 가중치 합산 (Hybrid Score)
        hybrid_score = (emb_score * weights["embedding"]) + (llm_score * weights["llm"])
        
        item["emb_score"] = emb_score
        item["hybrid_score"] = hybrid_score
        
        final_list.append(item)

    # 하이브리드 점수(hybrid_score) 기준으로 내림차순 정렬
    final_list.sort(key=lambda x: x.get("hybrid_score", 0), reverse=True)
    
    print(f"--- [Filter] 5. 최종 정렬 완료 (상위 3개 선별) ---")
    
    # 상위 3개만 반환
    return final_list[:3]


# ---------------------------- 메인 실행 함수 ----------------------------

# [!!! 여기를 수정 !!!]
def run_festival_recommendation(
    store_profile: dict,
    user_query: str,
    top_k: int, # orchestrator.py에서 15를 전달
    llm: ChatGoogleGenerativeAI, # [수정] orchestrator.py에서 주입받음
    vector_store: FAISS,         # [수정] orchestrator.py에서 주입받음
    final_n: int = 3
) -> Dict[str, Any]:
    """
    (수정됨) 고도화된 축제 추천 파이프라인 전체를 실행합니다.
    LLM과 Vector Store를 외부(Orchestrator)에서 주입받습니다.
    (1) 쿼리 재작성 -> (2) FAISS 검색 -> (3) 동적 기준 생성 -> (4) 일괄 평가 -> (5) 최종 스코어링
    """
    
    try:
        # 0. 모듈 초기화 (LLM 및 벡터 저장소)
        # [수정] 아래 두 줄을 제거하고, 주입받은 객체를 사용합니다.
        # llm = _init_llm(temperature=0.1) 
        # vector_store, embeddings = load_festival_vector_store()
        
        # [수정] 주입받은 vector_store가 유효한지 확인합니다.
        if vector_store is None:
            return {"error": "축제 벡터 저장소(FAISS)가 주입되지 않았습니다."}
        
        # [수정] 주입받은 llm 객체를 사용합니다.

        # 1. (LLM 1회) 의미 검색용 쿼리 재작성
        rewritten_query = rewrite_query_with_llm(store_profile, user_query, llm=llm)

        # 2. (FAISS) 후보군 검색
        candidates_docs = search_faiss_candidates(rewritten_query, vector_store, k=top_k)
        if not candidates_docs:
            return {"error": "FAISS 검색 결과, 연관된 축제를 찾지 못했습니다."}

        # 임베딩 점수(유사도) 맵핑 및 후보 문서 리스트 정리
        emb_scores_map = {}
        candidate_doc_list = []
        for doc, score in candidates_docs:
            # FAISS의 L2 거리는 (0 ~ 4) 범위, 유사도로 변환 (1에 가까울수록 좋음)
            if isinstance(score, (int, float)) and score > 1.0: # L2 거리로 가정
                sim = 1.0 - (float(score) / 4.0) # L2 정규화 (최대 4로 가정)
            else: # 코사인 유사도 (이미 0~1 범위)
                sim = float(score)
                
            festival_name = doc.metadata.get("festival_name") or doc.metadata.get("축제명")
            if festival_name:
                # 0~1 사이의 유사도 점수 저장
                emb_scores_map[festival_name] = max(0, sim) 
            candidate_doc_list.append(doc)

        # 3. (LLM 2회) 동적 채점 기준 생성
        scoring_criteria = create_dynamic_scoring_criteria(store_profile, user_query, llm=llm)

        # 4. (LLM 3회) [!!! 속도 개선 !!!]
        #    후보 축제 N개를 *일괄 평가* (기존 N회 호출 -> 1회 호출)
        
        # --- [수정] N+1 호출 루프를 단일 함수 호출로 변경 ---
        evaluated_candidates = evaluate_candidates_in_batch(
            candidate_doc_list,
            scoring_criteria,
            store_profile,
            rewritten_query, # 재작성된 쿼리를 평가 시에도 사용
            llm=llm
        )
        # --- [수정] 완료 ---
        
        if not evaluated_candidates:
             return {"error": "LLM이 후보 축제를 평가하는 데 실패했습니다."}

        # 5. 하이브리드 스코어링 및 최종 Top N (3개) 선정
        final_recommendations = calculate_hybrid_scores(
            evaluated_candidates,
            emb_scores_map,
            weights={"embedding": 0.4, "llm": 0.6} # 가중치 (임베딩 40%, LLM 60%)
        )

        # [수정] final_n 매개변수를 사용하도록 수정 (필요시)
        # (현재 calculate_hybrid_scores 함수 내부에 3개가 하드코딩되어 있으나,
        #  추후 final_n을 사용하도록 해당 함수를 수정할 수 있습니다.)
        # final_recommendations = final_recommendations[:final_n] 

        return {
            "recommendations": final_recommendations,
            "scoring_criteria": scoring_criteria,
            "rewritten_query": rewritten_query
        }

    except Exception as e:
        print(f"--- [Filter CRITICAL] run_festival_recommendation 실패: {e} ---")
        traceback.print_exc()
        return {"error": f"축제 추천 중 심각한 오류 발생: {e}"}