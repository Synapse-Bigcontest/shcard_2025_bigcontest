# modules/tool_definitions.py

import requests
import pandas as pd
import os
from datetime import datetime
from langchain_core.tools import tool
import numpy as np
import traceback
from pathlib import Path

API_SERVER_URL = "http://127.0.0.1:8000/profile"

def _load_and_process_festivals():
    print("--- [Cache] 'festival_df.csv' 최초 로딩 및 전처리 시작... ---")
    try:
        project_root = Path(__file__).resolve().parent.parent
        file_path = project_root / 'data' / 'festival_df.csv'
        if not file_path.exists():
            raise FileNotFoundError(f"데이터 파일을 찾을 수 없습니다: {file_path}")
        
        df = pd.read_csv(file_path)
        
        # --- [추가] 파일 로드 후 데이터가 비어 있는지 확인 ---
        if df.empty:
            raise ValueError("'festival_df.csv' 파일에 데이터가 없습니다.")

        date_column_name = '2025_기간'
        if date_column_name not in df.columns:
             raise KeyError(f"'{date_column_name}' 컬럼을 festival_df.csv 파일에서 찾을 수 없습니다.")

        df['date'] = df[date_column_name].astype(str).str.split('~').str[0].str.strip()
        df['date'] = pd.to_datetime(df['date'], errors='coerce').dt.strftime('%Y-%m-%d')
        
        df.dropna(subset=['date'], inplace=True)

        # --- [추가] 날짜 처리 후 데이터가 비어 있는지 다시 확인 ---
        if df.empty:
            raise ValueError("처리할 수 있는 유효한 날짜 데이터가 '2025_기간' 컬럼에 없습니다. 데이터 형식을 확인해주세요.")
        
        df.rename(columns={'축제명': 'festival_name', '소개': 'description'}, inplace=True)
        
        print("--- [Cache] 'festival_df.csv' 로딩 및 전처리 성공 ---")
        return df.to_dict('records')
        
    except Exception as e:
        print(f"--- [Cache CRITICAL] 'festival_df.csv' 로딩 실패: {e}\n{traceback.format_exc()} ---")
        return [{"error": f"축제 데이터 로딩 중 오류 발생: {e}"}]

PROCESSED_FESTIVAL_DATA = _load_and_process_festivals()

@tool
def get_merchant_profile(merchant_id: str) -> dict:
    """
    가게의 고유 ID(가맹점ID)를 입력받아 가게 프로필과 상권 평균 데이터를 반환합니다.
    (내부적으로 FastAPI 서버를 호출합니다.)
    """
    try:
        response = requests.post(API_SERVER_URL, json={"merchant_id": merchant_id})
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": f"API 서버 연결에 실패했습니다. 서버가 실행 중인지 확인해주세요. 에러: {e}"}
    except Exception as e:
        return {"error": f"가맹점 프로필 조회 중 오류 발생: {e}"}

@tool
def get_festival_info() -> list[dict]:
    """
    미리 캐싱된 'festival_df.csv' 데이터를 신속하게 반환합니다.
    """
    print("--- [Tool] 캐싱된 축제 정보를 즉시 반환합니다. ---")
    return PROCESSED_FESTIVAL_DATA