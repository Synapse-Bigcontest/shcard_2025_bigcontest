# modules/visualization.py

import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
import streamlit as st

def set_korean_font():
    """
    시스템에 설치된 한글 폰트를 찾아 Matplotlib에 설정합니다.
    'Malgun Gothic', 'AppleGothic', 'NanumGothic' 순으로 검색합니다.
    """
    font_list = ['Malgun Gothic', 'AppleGothic', 'NanumGothic']
    
    found_font = False
    # font_manager가 시스템의 모든 폰트를 뒤져서...
    for font_name in font_list:
        if any(font.name == font_name for font in font_manager.fontManager.ttflist):
            # 목록에 있는 폰트 이름과 일치하는 것을 찾아 적용합니다.
            plt.rc('font', family=font_name)
            print(f"✅ 한글 폰트 '{font_name}'을(를) 찾아 그래프에 적용합니다.")
            found_font = True
            break
            
    if not found_font:
        print("⚠️ 경고: Malgun Gothic, AppleGothic, NanumGothic 폰트를 찾을 수 없습니다.")
    
    plt.rcParams['axes.unicode_minus'] = False


def display_merchant_profile(profile_data: dict):
    # 모듈이 처음 임포트될 때 한글 폰트 설정을 자동으로 실행
    set_korean_font()

    """
    분석된 가맹점 프로필 전체를 Streamlit 화면에 시각화합니다.
    """
    if not profile_data or "store_profile" not in profile_data:
        st.error("분석할 가맹점 데이터가 없습니다.")
        return

    store_data = profile_data["store_profile"]
    average_data = profile_data.get("average_profile", {})

    st.info(f"**'{store_data.get('가맹점명', '선택 매장')}'**의 상세 분석 결과입니다. 동일 업종/상권의 평균 데이터와 비교하여 강점과 약점을 파악해보세요.")

    # 탭 UI로 깔끔하게 분리
    tab1, tab2, tab3, tab4 = st.tabs(["📊 주요 성과", "👥 고객 분포", "💖 고객 충성도", "🏙️ 상권 특성"])

    with tab1:
        st.subheader("📋 가맹점 성과 요약")
        render_summary_table(store_data, average_data)
        st.subheader("📈 주요 성과 지표 비교")
        fig1 = plot_performance(store_data, average_data)
        st.pyplot(fig1)

    with tab2:
        st.subheader("🧑‍🤝‍🧑 주요 고객층 분포 (성별/연령대)")
        fig2 = plot_customer_distribution(store_data)
        st.pyplot(fig2)

    with tab3:
        st.subheader("🔁 고객 재방문 및 신규 유입 비교")
        fig3 = plot_customer_loyalty(store_data, average_data)
        st.pyplot(fig3)

    with tab4:
        st.subheader("🚶 상권 내 고객 유형 비교")
        fig4 = plot_area_characteristics(store_data, average_data)
        st.pyplot(fig4)


def render_summary_table(store_data, average_data):
    """요약 정보를 표로 렌더링합니다."""
    summary_df = pd.DataFrame({
        "항목": [
            "월평균 매출액 구간", "월평균 매출 건수 구간", "재이용 고객 비율", "신규 고객 비율",
            "동일 업종 내 매출 순위(상위 %)", "동일 상권 내 매출 순위(상위 %)"
        ],
        "가맹점": [
            store_data.get("월매출금액_구간", "N/A"),
            store_data.get("월매출건수_구간", "N/A"),
            f"{store_data.get('재이용고객비율', 0):.1f}%",
            f"{store_data.get('신규고객비율', 0):.1f}%",
            f"{store_data.get('동일업종내매출순위비율', 0):.1f}%",
            f"{store_data.get('동일상권내매출순위비율', 0):.1f}%"
        ],
        "상권/업종 평균": [
            f"{average_data.get('월매출금액_구간', 0):.1f}",
            f"{average_data.get('월매출건수_구간', 0):.1f}",
            f"{average_data.get('재이용고객비율', 0):.1f}%",
            f"{average_data.get('신규고객비율', 0):.1f}%",
            f"{average_data.get('동일업종내매출순위비율', 0):.1f}%",
            f"{average_data.get('동일상권내매출순위비율', 0):.1f}%"
        ]
    })

    # ✅ Arrow 변환 에러 방지: 모든 값을 문자열로 통일
    summary_df = summary_df.astype(str)

    st.table(summary_df.set_index('항목'))


def plot_performance(store_data, average_data):
    """주요 성과 지표 (매출/건수/고객수/객단가)를 비교하는 막대 그래프를 생성합니다."""
    labels = ['매출액', '매출건수', '고객수', '객단가']
    store_values = [
        store_data.get("월매출금액_구간", 0),
        store_data.get("월매출건수_구간", 0),
        store_data.get("월유니크고객수_구간", 0),
        store_data.get("월객단가_구간", 0)
    ]
    avg_values = [
        average_data.get("월매출금액_구간", 0),
        average_data.get("월매출건수_구간", 0),
        average_data.get("월유니크고객수_구간", 0),
        average_data.get("월객단가_구간", 0)
    ]

    x = np.arange(len(labels))
    width = 0.35
    fig, ax = plt.subplots(figsize=(10, 6))
    rects1 = ax.bar(x - width/2, store_values, width, label='가맹점', color='royalblue')
    rects2 = ax.bar(x + width/2, avg_values, width, label='상권/업종 평균', color='lightgray')

    ax.set_ylabel('구간 (숫자가 클수록 높음)')
    ax.set_title('주요 성과 지표 (구간별 비교)', fontsize=16)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=12)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    
    ax.bar_label(rects1, padding=3)
    ax.bar_label(rects2, padding=3)
    
    fig.tight_layout()
    return fig


def plot_customer_distribution(store_data):
    """고객 특성 분포 (성별/연령대)를 보여주는 막대 그래프를 생성합니다."""
    labels = ['20대 이하', '30대', '40대', '50대 이상']
    male_percents = [
        store_data.get('남성20대이하비율', 0), store_data.get('남성30대비율', 0),
        store_data.get('남성40대비율', 0),
        store_data.get('남성50대비율', 0) + store_data.get('남성60대이상비율', 0)
    ]
    female_percents = [
        store_data.get('여성20대이하비율', 0), store_data.get('여성30대비율', 0),
        store_data.get('여성40대비율', 0),
        store_data.get('여성50대비율', 0) + store_data.get('여성60대이상비율', 0)
    ]

    x = np.arange(len(labels))
    width = 0.35
    fig, ax = plt.subplots(figsize=(10, 6))
    rects1 = ax.bar(x - width/2, male_percents, width, label='남성', color='cornflowerblue')
    rects2 = ax.bar(x + width/2, female_percents, width, label='여성', color='salmon')

    ax.set_ylabel('고객 비율 (%)')
    ax.set_title('주요 고객층 분포 (성별/연령대)', fontsize=16)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=12)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)

    ax.bar_label(rects1, padding=3, fmt='%.1f')
    ax.bar_label(rects2, padding=3, fmt='%.1f')
    
    fig.tight_layout()
    return fig


def plot_customer_loyalty(store_data, average_data):
    """고객 충성도 (재방문/신규)를 비교하는 막대 그래프를 생성합니다."""
    labels = ['재이용 고객', '신규 고객']
    store_values = [store_data.get('재이용고객비율', 0), store_data.get('신규고객비율', 0)]
    avg_values = [average_data.get('재이용고객비율', 0), average_data.get('신규고객비율', 0)]

    x = np.arange(len(labels))
    width = 0.35
    fig, ax = plt.subplots(figsize=(8, 6))
    rects1 = ax.bar(x - width/2, store_values, width, label='가맹점', color='seagreen')
    rects2 = ax.bar(x + width/2, avg_values, width, label='상권/업종 평균', color='lightgray')

    ax.set_ylabel('비율 (%)')
    ax.set_title('고객 충성도 비교', fontsize=16)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=12)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)

    ax.bar_label(rects1, padding=3, fmt='%.1f')
    ax.bar_label(rects2, padding=3, fmt='%.1f')
    
    fig.tight_layout()
    return fig


def plot_area_characteristics(store_data, average_data):
    """상권 고객 유형 (거주자, 직장인, 유동인구)을 비교하는 막대 그래프를 생성합니다."""
    labels = ["거주자", "직장인", "유동인구"]
    store_values = [
        store_data.get("거주자이용비율", 0),
        store_data.get("직장인이용비율", 0),
        store_data.get("유동인구이용비율", 0)
    ]
    avg_values = [
        average_data.get("거주자이용비율", 0),
        average_data.get("직장인이용비율", 0),
        average_data.get("유동인구이용비율", 0)
    ]
    
    x = np.arange(len(labels))
    width = 0.35
    fig, ax = plt.subplots(figsize=(10, 6))
    rects1 = ax.bar(x - width/2, store_values, width, label='가맹점', color='darkorange')
    rects2 = ax.bar(x + width/2, avg_values, width, label='상권/업종 평균', color='lightgray')

    ax.set_ylabel('이용 비율 (%)')
    ax.set_title('상권 고객 유형 비교', fontsize=16)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=12)
    ax.legend()
    ax.grid(axis='y', linestyle='--', alpha=0.7)
    
    ax.bar_label(rects1, padding=3, fmt='%.1f')
    ax.bar_label(rects2, padding=3, fmt='%.1f')

    fig.tight_layout()
    return fig