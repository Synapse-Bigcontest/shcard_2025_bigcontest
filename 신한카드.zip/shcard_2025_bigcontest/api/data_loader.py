# api/data_loader.py

import pandas as pd
import os
from pathlib import Path # --- [추가] pathlib 라이브러리 임포트

def load_and_preprocess_data():
    """
    미리 가공된 final_df.csv 파일을 안전하게 찾아 로드하고,
    데이터를 처리하는 과정에서 발생할 수 있는 모든 오류를 방어합니다.
    """
    try:
        # --- [수정] pathlib를 사용하여 어떤 위치에서 실행하든 프로젝트 루트를 찾도록 경로 설정 ---
        # 이 파일(data_loader.py)의 위치를 기준으로 상위 폴더(api)의 상위 폴더(프로젝트 루트)를 찾습니다.
        project_root = Path(__file__).resolve().parent.parent
        file_path = project_root / 'data' / 'final_df.csv'
        # --- 수정 완료 ---

        if not file_path.exists():
            print(f"--- [CRITICAL DATA ERROR] 데이터 파일을 찾을 수 없습니다. 예상 경로: {file_path}")
            print(f"--- 현재 작업 경로: {Path.cwd()} ---")
            print("--- 'final_df.csv' 파일이 'data' 폴더 내에 있는지, 프로젝트 구조가 올바른지 확인해주세요. ---")
            return None
            
        df = pd.read_csv(file_path)

    except Exception as e:
        print(f"--- [CRITICAL DATA ERROR] 데이터 파일 로딩 중 예측하지 못한 오류 발생: {e} ---")
        return None
        
    # --- 👇 [수정 필요] Streamlit Arrow 변환 오류 방지용 클리닝 로직 추가 👇 ---
    print("--- [Preprocess] Streamlit Arrow 변환 오류 방지용 데이터 클리닝 시작 ---")
    for col in df.select_dtypes(include='object').columns:
        # 1. 문자열에서 '%'와 쉼표(,)를 제거하고 공백을 없앱니다.
        temp_series = (
            df[col]
            .astype(str)
            .str.replace('%', '', regex=False)
            .str.replace(',', '', regex=False)
            .str.strip()
        )
        
        # 2. to_numeric을 사용하여 안전하게 숫자(float)로 변환을 시도합니다.
        #    (FutureWarning 해결 및 명시적 예외 처리)
        numeric_series = pd.to_numeric(temp_series, errors='coerce') 
        
        # 3. 변환에 성공한 값만 numeric_series를 사용하고, 변환에 실패한 값(NaN이 된 값)은
        #    원래의 클리닝된 문자열 값(temp_series)을 사용하여 object 타입을 유지합니다.
        df[col] = numeric_series.fillna(temp_series)
        
    print("--- [Preprocess] 데이터 클리닝 완료 ---")
    # --- 👆 클리닝 로직 끝 👆 ---

    # 숫자형 구간 데이터를 안전하게 변환하는 로직
    cols_to_process = ['월매출금액_구간', '월매출건수_구간', '월유니크고객수_구간', '월객단가_구간']
    
    for col in cols_to_process:
        if col in df.columns:
            try:
                series_str = df[col].astype(str).fillna('')
                series_split = series_str.str.split('_').str[0]
                series_numeric = pd.to_numeric(series_split, errors='coerce')
                df[col] = series_numeric.fillna(0).astype(int)
            except Exception as e:
                print(f"--- [DATA WARNING] '{col}' 컬럼 처리 중 오류 발생: {e}. 해당 컬럼을 건너뜁니다. ---")
                continue
                
    return df