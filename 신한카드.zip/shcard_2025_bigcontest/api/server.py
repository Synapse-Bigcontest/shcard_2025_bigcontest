# api/server.py

import uvicorn
import json
import numpy as np
import pandas as pd
import traceback
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import math

from data_loader import load_and_preprocess_data

# --- Data Loading ---
DF_MERCHANT = load_and_preprocess_data()
if DF_MERCHANT is None:
    print("--- [API Server Error] 데이터 로딩 실패. 서버를 종료합니다. ---")
    exit()

# --- FastAPI App & Models ---
app = FastAPI()

class MerchantRequest(BaseModel):
    merchant_id: str

def replace_nan_with_none(data):
    """
    딕셔셔너리나 리스트 내의 모든 NaN 값을 None으로 재귀적으로 변환합니다.
    """
    if isinstance(data, dict):
        return {k: replace_nan_with_none(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [replace_nan_with_none(i) for i in data]
    elif isinstance(data, float) and math.isnan(data):
        return None
    return data

# --- API Endpoint ---
@app.post("/profile")
def get_merchant_profile(request: MerchantRequest):
    """
    가맹점 ID를 받아 프로파일링된 데이터와 동종/동일 상권 평균 데이터를 반환합니다.
    동일한 ID의 데이터가 여러 개 있을 경우, '기준년월'이 가장 최신인 데이터를 사용합니다.
    """
    merchant_id = request.merchant_id
    print(f"✅ [API] 가맹점 ID '{merchant_id}' 프로파일링 요청 수신")
    try:
        # --- [핵심 수정] 동일 가맹점ID 중 최신 데이터 선택 로직 ---
        
        # 1. 해당 가맹점ID를 가진 모든 데이터를 찾습니다.
        store_df_multiple = DF_MERCHANT[DF_MERCHANT['가맹점ID'] == merchant_id]

        # 2. 데이터가 하나도 없으면 404 에러를 발생시킵니다.
        if store_df_multiple.empty:
            raise HTTPException(status_code=404, detail=f"'{merchant_id}' 가맹점 ID를 찾을 수 없습니다.")
        
        # 3. 데이터가 여러 개 있으면 '기준년월'을 기준으로 내림차순 정렬하여 가장 최신 데이터를 선택합니다.
        #    '기준년월'을 datetime 객체로 변환하여 정확하게 정렬합니다.
        if len(store_df_multiple) > 1:
            print(f"   [INFO] '{merchant_id}'에 대해 {len(store_df_multiple)}개의 데이터 발견. 최신 데이터로 필터링합니다.")
            temp_df = store_df_multiple.copy()
            temp_df['기준년월_dt'] = pd.to_datetime(temp_df['기준년월'])
            latest_store_df = temp_df.sort_values(by='기준년월_dt', ascending=False).iloc[[0]]
        else:
            latest_store_df = store_df_multiple

        # 4. 최종 선택된 최신 데이터 1건을 딕셔너리로 변환합니다.
        store_data = latest_store_df.iloc[0].to_dict()
        
        # --- 수정 완료 ---

        # 자동 특징 추출
        store_data['자동추출특징'] = {
            "핵심고객": f"{'남성' if store_data.get('남성고객비율', 0) > store_data.get('여성고객비율', 0) else '여성'} 중심",
            "핵심연령대": max(['20대이하', '30대', '40대', '50대이상'], key=lambda age: store_data.get(f"연령대{age}고객비율", 0)),
            "매출순위": f"상권 내 상위 {store_data.get('동일상권내매출순위비율', 0):.1f}%, 업종 내 상위 {store_data.get('동일업종내매출순위비율', 0):.1f}%"
        }

        area = store_data.get('상권')
        category = store_data.get('업종')
        
        average_df = DF_MERCHANT[(DF_MERCHANT['상권'] == area) & (DF_MERCHANT['업종'] == category)]

        if average_df.empty:
            average_data = {}
        else:
            numeric_cols = average_df.select_dtypes(include=np.number).columns
            average_data = average_df[numeric_cols].mean().to_dict()

        average_data['가맹점명'] = f"{area} {category} 업종 평균"
        
        final_result = {
            "store_profile": store_data,
            "average_profile": average_data
        }
        
        clean_result = replace_nan_with_none(final_result)
        
        print(f"✅ [API] '{store_data.get('가맹점명')}({merchant_id})' 프로파일링 성공 (기준년월: {store_data.get('기준년월')})")
        return clean_result

    except HTTPException as e:
        print(f"❌ [API ERROR] 처리 중 오류: {e.detail}")
        raise e
    except Exception as e:
        print(f"❌ [API CRITICAL] 예측하지 못한 오류: {e}\n{traceback.format_exc()}")
        raise HTTPException(status_code=500, detail=f"서버 내부 오류 발생: {e}")

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8000)